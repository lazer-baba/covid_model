import sys, pygame
from random import *
import random
import time

start = time.time()
elapsed = 0


img_file1 = "myball1.png"
img_file2 = "myball2.png"
img_file3 = "myball3.png"


class MyBallClass(pygame.sprite.Sprite):
    def __init__(self, img_file, location, speed):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(img_file)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = location
        self.speed = speed

    def move(self):
        self.rect = self.rect.move(self.speed)
        if self.rect.left - 5 < 0 or self.rect.right + 5 > width:
            self.speed[0] = -self.speed[0]
        if self.rect.top - 5 < 0 or self.rect.bottom + 5 > height:
            self.speed[1] = -self.speed[1]


def animation(group):
    screen.fill([255, 255, 255])

    for ball in group:
        group.remove(ball)
        if pygame.sprite.spritecollide(ball, group, False):
            ball.speed[0] = -ball.speed[0]
            ball.speed[1] = -ball.speed[1]
        group.add(ball)
        group3.add(ball)
        ball.move()
        screen.blit(ball.image, ball.rect)

    for ball in group:
        group.remove(ball)
        if pygame.sprite.spritecollide(ball, group1, False):
            ball.image = pygame.image.load("myball2.png")
            ball.speed[0] = -ball.speed[0]
            ball.speed[1] = -ball.speed[1]
            group1.add(ball)
            group3.add(ball)
        else:
            group.add(ball)
            group3.add(ball)

        ball.move()
        screen.blit(ball.image, ball.rect)

    for ball in group1:
        group1.remove(ball)
        if pygame.sprite.spritecollide(ball, group1, False):
            ball.speed[0] = -ball.speed[0]
            ball.speed[1] = -ball.speed[1]
        group1.add(ball)
        group3.add(ball)
        ball.move()
        screen.blit(ball.image, ball.rect)

    for ball in group1:
        group1.remove(ball)
        if pygame.sprite.spritecollide(ball, group, False):
            ball.speed[0] = -ball.speed[0]
            ball.speed[1] = -ball.speed[1]
        group1.add(ball)
        group3.add(ball)
        ball.move()
        screen.blit(ball.image, ball.rect)

    for ball in group1:
        group1.remove(ball)
        elapsed = time.time() - start
        r1 = random.randrange(0, 9000, 1)
        if elapsed > 10:# and elapsed % 0.25==0:
            if r1 % 555 == 0:
                ball.image = pygame.image.load("myball3.png")
        group1.add(ball)
        group3.add(ball)

        ball.move()
        screen.blit(ball.image, ball.rect)

    pygame.display.flip()
    pygame.time.delay(20)


size = width, height = 1200, 700
screen = pygame.display.set_mode(size)
pygame.display.set_caption('Cronavirus Model of a City')
screen.fill([255, 255, 255])

group = pygame.sprite.Group()
group1 = pygame.sprite.Group()
group3 = pygame.sprite.Group()

for r in range(0, 150):
    location = [random.randrange(10, width - 10, 20), random.randrange(10, height - 10, 20)]
    speed = [choice([-1, 1]), choice([-1, 1])]
    ball = MyBallClass(img_file1, location, speed)
    group.add(ball)
    group3.add(ball)

for r in range(0, 3):
    location = [random.randrange(10, width - 10, 20), random.randrange(10, height - 10, 20)]
    speed = [choice([-1, 1]), choice([-1, 1])]
    ball = MyBallClass(img_file2, location, speed)
    group1.add(ball)
    group3.add(ball)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
    animation(group)